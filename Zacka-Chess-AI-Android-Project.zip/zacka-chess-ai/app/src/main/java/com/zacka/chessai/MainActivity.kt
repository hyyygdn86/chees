package com.zacka.chessai

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val startFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    private lateinit var fenInput: EditText
    private lateinit var result: TextView
    private lateinit var analyzeButton: Button
    private var engine: Process? = null
    private var writer: java.io.BufferedWriter? = null
    private var reader: BufferedReader? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24) }
        val title = TextView(this).apply { text = "ZACKA CHESS AI"; textSize = 25f; typeface = Typeface.DEFAULT_BOLD }
        val subtitle = TextView(this).apply { text = "Stockfish • Offline chess analysis"; textSize = 14f; setPadding(0, 4, 0, 18) }
        fenInput = EditText(this).apply {
            setText(startFen); textSize = 13f; minLines = 3; gravity = Gravity.TOP
            hint = "Masukkan posisi FEN"
        }
        val analyze = Button(this).apply { text = "ANALISIS POSISI"; isAllCaps = false }
        analyzeButton = analyze
        val reset = Button(this).apply { text = "Posisi awal"; isAllCaps = false }
        result = TextView(this).apply { text = "Siap. Tekan ANALISIS POSISI untuk meminta langkah terbaik dari Stockfish."; textSize = 16f; setPadding(0, 18, 0, 0) }
        analyze.setOnClickListener { analyzePosition() }
        reset.setOnClickListener { fenInput.setText(startFen); result.text = "Posisi dikembalikan ke posisi awal." }
        root.addView(title); root.addView(subtitle); root.addView(fenInput)
        root.addView(analyze); root.addView(reset); root.addView(result)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun analyzePosition() {
        val fen = fenInput.text.toString().trim()
        if (fen.split(Regex("\\s+")).size != 6) {
            result.text = "FEN tidak valid: format harus memiliki 6 bagian."; return
        }
        analyzeButton.isEnabled = false
        result.text = "Menjalankan Stockfish…"
        thread {
            try {
                val process = ensureEngine()
                val out = writer ?: error("Engine input unavailable")
                val input = reader ?: error("Engine output unavailable")
                synchronized(out) {
                    out.write("ucinewgame\n")
                    out.write("isready\n")
                    out.flush()
                }
                var ready = false
                var guard = 0
                while (!ready && guard++ < 200) {
                    val line = input.readLine() ?: break
                    if (line.trim() == "readyok") ready = true
                }
                if (!ready) error("Stockfish tidak merespons.")
                synchronized(out) {
                    out.write("position fen $fen\n")
                    out.write("go depth 13\n")
                    out.flush()
                }
                var best = ""
                val info = StringBuilder()
                guard = 0
                while (guard++ < 500) {
                    val line = input.readLine() ?: break
                    if (line.startsWith("info ") && line.contains(" depth ")) info.append(line).append('\n')
                    if (line.startsWith("bestmove ")) { best = line; break }
                }
                runOnUiThread {
                    result.text = if (best.isNotBlank()) "HASIL STOCKFISH\n\n$best\n\nAnalisis selesai (depth 13).\n\n${info.toString().lineSequence().takeLast(5).joinToString("\n")}" else "Engine tidak menghasilkan langkah. Periksa FEN dan giliran bermain."
                    analyzeButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { result.text = "Gagal menjalankan engine: ${e.message}\n\nPastikan binary Stockfish ARM64 sudah disertakan."; analyzeButton.isEnabled = true }
            }
        }
    }

    @Synchronized private fun ensureEngine(): Process {
        if (engine?.isAlive == true) return engine!!
        val executable = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!executable.exists()) error("Binary Stockfish belum ada di aplikasi.")
        engine = ProcessBuilder(executable.absolutePath).redirectErrorStream(true).start()
        writer = engine!!.outputStream.bufferedWriter()
        reader = BufferedReader(InputStreamReader(engine!!.inputStream))
        val out = writer!!
        out.write("uci\n"); out.flush()
        var uciOk = false
        var count = 0
        while (!uciOk && count++ < 300) {
            val line = reader!!.readLine() ?: break
            if (line.trim() == "uciok") uciOk = true
        }
        if (!uciOk) error("Handshake UCI gagal.")
        return engine!!
    }

    override fun onDestroy() {
        try { writer?.write("quit\n"); writer?.flush() } catch (_: Exception) {}
        engine?.destroy()
        super.onDestroy()
    }
}
