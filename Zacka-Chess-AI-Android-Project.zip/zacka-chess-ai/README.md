# Zacka Chess AI (Android starter)

An Android starter app that runs the official Stockfish Android ARM64 engine locally and requests a best move for a supplied FEN position.

## Current MVP scope
- Android app UI with editable FEN input
- Stockfish UCI process launched on-device
- Offline analysis after the engine is packaged
- GitHub Actions workflow that downloads the official Android ARM64 Stockfish binary and builds a debug APK

This is an engine-analysis MVP, not yet a full chess GUI: legal move interaction, clocks, game history, and difficulty presets are not implemented yet.

## Build APK using GitHub Actions
1. Create a new GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build Android APK** using **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the `Zacka-Chess-AI-APK` artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

The workflow fetches the official Stockfish Android ARM64 universal binary from the official Stockfish release page. This build targets 64-bit ARM Android phones. If the phone is 32-bit ARM, this APK will not run.

## License note
Stockfish is GPLv3. If you redistribute the resulting app, include the applicable GPLv3 license text and corresponding source for the exact Stockfish binary. See https://github.com/official-stockfish/Stockfish and https://stockfishchess.org/download/.
